
import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;

public class Look_C_Look {
    public static void main(String[] args) throws Exception{
        
        Scanner in = new Scanner(System.in);

        System.out.println("Enter the disk size: ");
        int d_size = in.nextInt();
        System.out.println("Enter the request sequence array size: ");
        int n = in.nextInt();
        int[] req_seq = new int[n];
        
        for(int i = 0; i<n; i++){
            System.out.println("Enter array element number " +(i+1));
            req_seq[i] = in.nextInt();
        }

        System.out.println("The request sequence array is: ");
        for(int i =0; i<n; i++){
            System.out.print(req_seq[i] +" ");
        }

        System.out.println("\nEnter the head value: ");
        int head = in.nextInt();

        System.out.println("The disk scheduling algorithms available are: ");
        System.out.println("1.) Look");
        System.out.println("2.) C-Look");
        System.out.println("Enter your choice: ");
        int choice = in.nextInt();

        if(choice == 1){
            // System.out.println("Enter the direction you want to progress in (this is required for LOOK algorithm): ");
            // String Direction = in.next();
            LOOK(req_seq, head);//, Direction);
        }

        else if(choice == 2){
            C_Look(req_seq, head);
        }

        else{
            System.out.println("!!Please make a valid selection!!");
        }

        in.close();
    }

    static void C_Look(int arr[], int head){

        int seek_value = 0;
        int distance, current_track;

        int size = arr.length;

        Vector<Integer> left = new Vector<Integer>();
        Vector<Integer> right = new Vector<Integer>();
        Vector<Integer> seek_sequence = new Vector<Integer>();

        for(int i = 0; i<size; i++){
            if (arr[i] < head){
                left.add(arr[i]);
            }

            else if(arr[i] > head){
                right.add(arr[i]);
            }
        }

        Collections.sort(left);
        Collections.sort(right);

        for(int i =0; i<right.size(); i++){

            current_track = right.get(i);
            seek_sequence.add(current_track);

            distance = Math.abs(current_track - head);
            seek_value = seek_value + distance;
            head = current_track;
        }

        seek_value = seek_value + Math.abs(head-left.get(0));
        head = left.get(0);

        for(int i = 0; i<left.size(); i++){
            current_track = left.get(i);
            seek_sequence.add(current_track);
            distance = Math.abs(current_track - head);
            seek_value = seek_value + distance;
        }

        System.out.println("The total number of seek operations is: " +seek_value);
        System.out.println("The seek sequence is: ");
        for(int i =0; i<seek_sequence.size(); i++){
            System.out.println(seek_sequence.get(i));
        }
    }

    public static void LOOK(int arr[], int head){

        int seek_number = 0;
        int distance, current_track;

        int size = 8;

        Vector<Integer> left = new Vector<Integer>();
        Vector<Integer> right = new Vector<Integer>();
        Vector<Integer> seek_seq = new Vector<Integer>();

        for(int i = 0; i<size; i++){
            if (arr[i] < head){
                left.add(arr[i]);
            }

            else if(arr[i] > head){
                right.add(arr[i]);
            }
        }

        Collections.sort(left);
        Collections.sort(right);

        int run = 2;

        while(run-- > 0){

            // if(direction == "left"){
                
            //     for(int i = left.size() - 1; i>=0; i--){
            //         current_track = left.get(i);
            //         seek_seq.add(current_track);
            //         distance = Math.abs(current_track - head);
            //         seek_number += distance;
            //         head = current_track;
            //     }

            //     direction = "right";

            // }

            
            for(int i = 0; i<right.size(); i++){
                current_track = right.get(i);
                seek_seq.add(current_track);
                distance = Math.abs(current_track - head);
                seek_number += distance;
                head = current_track;
            }

        }

        System.out.println("The total number of seek operations is: " +seek_number);
        System.out.println("The seek sequence is: ");
        for(int i = 0; i<seek_seq.size(); i++){
            System.out.println(seek_seq.get(i));
        }
    }
}
